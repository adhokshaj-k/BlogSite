import matplotlib.pyplot as plt
import numpy as np

from sklearn import datasets
from sklearn.linear_model import LogisticRegression


# Load Iris dataset
iris = datasets.load_iris()

# Select Petal Length and Petal Width
x = iris["data"][:, (2, 3)]

# Target:
# 1 if Iris Virginica
# 0 otherwise
y = (iris["target"] == 2).astype(np.int64)


# Create Logistic Regression model
log_reg2 = LogisticRegression(
    solver="lbfgs",
    C=10**10,
    random_state=42
)

# Train model
log_reg2.fit(x, y)


# Create mesh grid
x0, x1 = np.meshgrid(
    np.linspace(2.9, 7, 500).reshape(-1, 1),
    np.linspace(0.8, 2.7, 200).reshape(-1, 1),
)

# Combine coordinates
x_new = np.c_[x0.ravel(), x1.ravel()]

print(x_new.shape)


# Predict probabilities
y_proba = log_reg2.predict_proba(x_new)


# Plot graph
plt.figure(figsize=(10, 4))

# Blue squares for class 0
plt.plot(
    x[y == 0, 0],
    x[y == 0, 1],
    "bs"
)

# Green triangles for class 1
plt.plot(
    x[y == 1, 0],
    x[y == 1, 1],
    "g^"
)

# Probability contour
zz = y_proba[:, 1].reshape(x0.shape)

contour = plt.contour(
    x0,
    x1,
    zz,
    cmap=plt.cm.brg
)


# Decision boundary
left_right = np.array([2.9, 7])

boundary = -(
    log_reg2.coef_[0][0] * left_right
    + log_reg2.intercept_[0]
) / log_reg2.coef_[0][1]


# Labels on contour
plt.clabel(
    contour,
    inline=1,
    fontsize=12
)

# Draw boundary line
plt.plot(
    left_right,
    boundary,
    "k--",
    linewidth=3
)

# Text labels
plt.text(
    3.5,
    1.5,
    "Not Iris Virginica",
    fontsize=14,
    color="g",
    ha="center"
)

# Axis labels
plt.xlabel("Petal Length", fontsize=14)
plt.ylabel("Petal Width", fontsize=14)

# Axis limits
plt.axis([2.9, 7, 0.8, 2.7])

# Show graph
plt.show()