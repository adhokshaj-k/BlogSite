
# Perceptron for OR Operation
# Training data

inputs = [(0,0), (0,1), (1,0), (1,1)]

labels = [0,1,1,1]

# Initialize weights and bias

w1 = 0.0
w2 = 0.0
bias = 0.0

learning_rate = 0.1

epochs = 10

# Step Activation Function

def step(x):
    return 1 if x >= 0 else 0

# Training Loop

for _ in range(epochs):

    for (x1, x2), label in zip(inputs, labels):

        # Weighted sum

        linear_output = w1*x1 + w2*x2 + bias

        # Prediction

        prediction = step(linear_output)

        # Error

        error = label - prediction

        # Weight Update

        w1 += learning_rate * error * x1
        w2 += learning_rate * error * x2

        # Bias Update

        bias += learning_rate * error

# Testing

print("Trained Weights:", w1, w2)

print("Bias:", bias)

print("\nTesting OR Gate")

for x1, x2 in inputs:

    output = step(w1*x1 + w2*x2 + bias)

    print(f"{x1} OR {x2} = {output}")

