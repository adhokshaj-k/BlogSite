
# Perceptron using Stochastic Gradient Descent (SGD)

import numpy as np

# Training Dataset for AND Gate

X = np.array([
    [0,0],
    [0,1],
    [1,0],
    [1,1]
])

# Target Output

y = np.array([0,0,0,1])

# Initialize Weights and Bias

weights = np.zeros(2)

bias = 0

# Learning Rate

lr = 0.1

# Number of Epochs

epochs = 10

# Activation Function

def activation(z):
    return 1 if z >= 0 else 0

# Training using SGD

for epoch in range(epochs):

    print(f"\nEpoch {epoch+1}")

    for i in range(len(X)):

        # Linear Combination

        z = np.dot(X[i], weights) + bias

        # Prediction

        y_pred = activation(z)

        # Error

        error = y[i] - y_pred

        # Weight Update

        weights = weights + lr * error * X[i]

        # Bias Update

        bias = bias + lr * error

        print(f"Input: {X[i]}, Predicted: {y_pred}, Error: {error}")

# Final Output

print("\nFinal Weights:", weights)

print("Final Bias:", bias)

# Testing

print("\nTesting Perceptron")

for i in range(len(X)):

    z = np.dot(X[i], weights) + bias

    prediction = activation(z)

    print(f"Input: {X[i]} -> Output: {prediction}")

