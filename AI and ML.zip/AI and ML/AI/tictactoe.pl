% --- Tic Tac Toe BFS Solver ---

% Initial empty board
initial([e,e,e,
         e,e,e,
         e,e,e]).

% Goal: X wins
goal(Board) :-
    win(Board, x).

% Winning conditions

win([P,P,P,_,_,_,_,_,_], P).
win([_,_,_,P,P,P,_,_,_], P).
win([_,_,_,_,_,_,P,P,P], P).

win([P,_,_,P,_,_,P,_,_], P).
win([_,P,_,_,P,_,_,P,_], P).
win([_,_,P,_,_,P,_,_,P], P).

win([P,_,_,_,P,_,_,_,P], P).
win([_,_,P,_,P,_,P,_,_], P).

% Switch player
next_player(x, o).
next_player(o, x).

% Generate next move
move(Board, Player, NewBoard) :-
    nth0(Index, Board, e),
    replace(Board, Index, Player, NewBoard).

% Replace element in list
replace([_|T], 0, X, [X|T]).

replace([H|T], I, X, [H|R]) :-
    I > 0,
    I1 is I - 1,
    replace(T, I1, X, R).

% --- BFS Implementation ---

bfs([[Board|Path]|_], _, [Board|Path]) :-
    goal(Board),
    !.

bfs([[Board|Path]|Queue], Player, Solution) :-
    findall(
        [NextBoard,Board|Path],
        move(Board, Player, NextBoard),
        Children
    ),

    append(Queue, Children, NewQueue),

    next_player(Player, NextPlayer),

    bfs(NewQueue, NextPlayer, Solution).

% Solve predicate
solve(Path) :-
    initial(Board),
    bfs([[Board]], x, RevPath),
    reverse(RevPath, Path).

% Print board
print_board([A,B,C,D,E,F,G,H,I]) :-

    format('~w | ~w | ~w~n', [A,B,C]),
    format('--+---+--~n'),

    format('~w | ~w | ~w~n', [D,E,F]),
    format('--+---+--~n'),

    format('~w | ~w | ~w~n~n', [G,H,I]).

% Print solution path
print_solution([]).

print_solution([Board|Rest]) :-
    print_board(Board),
    print_solution(Rest).

% Run everything
run :-
    solve(Path),
    print_solution(Path).

