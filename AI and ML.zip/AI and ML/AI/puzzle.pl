% Goal State
goal([1,2,3,
      4,5,6,
      7,8,0]).   % 0 represents blank

% Entry Point
solve(Start) :-
    hill_climb(Start, []).

% Hill Climbing Algorithm

hill_climb(State, _) :-
    goal(State),
    write('Goal Reached'), nl,
    print_state(State),
    !.

hill_climb(State, Visited) :-

    get_children(State, Children),

    exclude(member_of(Visited), Children, ValidChildren),

    evaluate_children(ValidChildren, ScoredChildren),

    sort(ScoredChildren, Sorted),

    Sorted = [[_, BestChild]|_],

    write('Current State:'), nl,
    print_state(State), nl,

    hill_climb(BestChild, [State|Visited]).

% Membership check

member_of(List, Element) :-
    member(Element, List).

% Generate Children

get_children(State, Children) :-
    findall(Child, move(State, Child), Children).

% Possible Moves

move(State, NewState) :-
    swap(State, 0, -3, NewState).   % Up

move(State, NewState) :-
    swap(State, 0, 3, NewState).    % Down

move(State, NewState) :-
    swap(State, 0, -1, NewState).   % Left

move(State, NewState) :-
    swap(State, 0, 1, NewState).    % Right

% Swap positions

swap(State, Zero, Move, NewState) :-

    nth0(Index, State, Zero),

    NewIndex is Index + Move,

    valid_move(Index, NewIndex),

    nth0(NewIndex, State, Value),

    set_element(State, Index, Value, Temp),

    set_element(Temp, NewIndex, Zero, NewState).

% Valid Moves

valid_move(I, J) :-
    J >= 0,
    J < 9,
    \+ invalid_edge(I, J).

invalid_edge(2,3).
invalid_edge(3,2).

invalid_edge(5,6).
invalid_edge(6,5).

% Replace Element

set_element([_|T], 0, X, [X|T]).

set_element([H|T], I, X, [H|R]) :-
    I > 0,
    I1 is I - 1,
    set_element(T, I1, X, R).

% Heuristic Function
% Misplaced Tiles

heuristic(State, H) :-
    goal(Goal),
    count_misplaced(State, Goal, H).

count_misplaced([], [], 0).

count_misplaced([0|T1], [_|T2], H) :-
    count_misplaced(T1, T2, H).

count_misplaced([H|T1], [H|T2], C) :-
    count_misplaced(T1, T2, C).

count_misplaced([H1|T1], [H2|T2], C) :-
    H1 \= H2,
    count_misplaced(T1, T2, C1),
    C is C1 + 1.

% Evaluate Children

evaluate_children([], []).

evaluate_children([State|Rest],
                  [[H,State]|ScoredRest]) :-

    heuristic(State, H),

    evaluate_children(Rest, ScoredRest).

% Print State

print_state([A,B,C,D,E,F,G,H,I]) :-

    write([A,B,C]), nl,
    write([D,E,F]), nl,
    write([G,H,I]), nl.

