% Define goal state
goal(state(2,_)).   % 2 liters in Jug A

% Define capacity
capacity(4,3).

% Move rules

% Fill Jug A
move(state(X,Y), state(4,Y)) :-
    X < 4.

% Fill Jug B
move(state(X,Y), state(X,3)) :-
    Y < 3.

% Empty Jug A
move(state(X,Y), state(0,Y)) :-
    X > 0.

% Empty Jug B
move(state(X,Y), state(X,0)) :-
    Y > 0.

% Pour A -> B
move(state(X,Y), state(X1,Y1)) :-
    X > 0,
    Y < 3,
    Transfer is min(X, 3-Y),
    X1 is X - Transfer,
    Y1 is Y + Transfer.

% Pour B -> A
move(state(X,Y), state(X1,Y1)) :-
    Y > 0,
    X < 4,
    Transfer is min(Y, 4-X),
    Y1 is Y - Transfer,
    X1 is X + Transfer.

% DFS Algorithm

dfs(State, _, [State]) :-
    goal(State).

dfs(State, Visited, [State|Path]) :-
    move(State, Next),
    \+ member(Next, Visited),
    dfs(Next, [Next|Visited], Path).

% Start predicate

solve(Path) :-
    dfs(state(0,0), [state(0,0)], Path).

id="0i6f6v"
print_path([]).

print_path([H|T]) :-
    writeln(H),
    print_path(T).

run :-
    solve(Path),
    print_path(Path).

