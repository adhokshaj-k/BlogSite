import numpy as np
import pandas as pd
from scipy import stats
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# 1. Create dataset using NumPy

hours = np.array([1,2,3,4,5,6,7,8])
marks = np.array([35,40,50,60,70,80,90,95])

print("Study Hours:")
print(hours)

print("\nMarks:")
print(marks)

# 2. Create DataFrame using Pandas

data = pd.DataFrame({
    'Study_Hours': hours,
    'Marks': marks
})

print("\nStudent Data:")
print(data)

# 3. Statistical Analysis using SciPy

mean_marks = np.mean(marks)
median_marks = np.median(marks)
mode_marks = stats.mode(marks)

print("\nStatistical Analysis")
print("Mean:", mean_marks)
print("Median:", median_marks)
print("Mode:", mode_marks.mode)

# 4. Data Visualization using Matplotlib

plt.plot(hours, marks, marker='o')

plt.title("Study Hours vs Marks")

plt.xlabel("Study Hours")
plt.ylabel("Marks")

plt.grid(True)

plt.show()

# 5. Machine Learning using Scikit-Learn

# Reshape data for model

x = hours.reshape(-1,1)
y = marks

# Create model

model = LinearRegression()

# Train model

model.fit(x, y)

# Predict marks for 9 study hours

predicted_marks = model.predict([[9]])

print("\nMachine Learning Prediction")
print("Predicted marks for 9 hours study:",
      predicted_marks[0])

